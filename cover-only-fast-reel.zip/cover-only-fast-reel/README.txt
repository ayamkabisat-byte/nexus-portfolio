COVER-ONLY FAST REEL

Changes:
- Only book covers move in the homepage reel.
- Automatic movement is faster.
- Hover/focus pauses movement for easier clicking.
- Clicking a cover opens its own /books/<slug>/ page.
- Dragging remains available.
- The second set of covers is decorative and hidden from accessibility tools.

Copy the package contents into the repository root:

  cp -a cover-only-fast-reel/. ./
  rm -rf .astro dist
  pnpm run check
  pnpm run build
  pnpm run dev -- --host 0.0.0.0

Speed is configured in src/scripts/site.ts:

  mobile: -58
  desktop: -84

Use larger negative numbers to make it faster.
