REMOVE INLINE BOOK SVG

This patch removes ALL old code-generated book-world graphics:
- book-world__bottle
- book-world__molecule
- book-world__sillage-lines
- book-world__portal
- book-world__nodes
- book-world__redactions
- book-world__poster-shard
- book-world__mask
- book-world__hydra-ring
- book-world__hydra-lines
- book-world__clock
- book-world__monas
- book-world__dream-orbit
- book-world__aperture
- book-world__focus-frame
- book-world__timestamp

After this, BookAtmosphere.astro contains only CinematicVideo:
video/<slug>.mp4 + worlds/<slug>.webp as poster fallback.

Install:
cd /workspaces/nexus-portfolio

unzip -q remove-inline-book-svg.zip -d /tmp/remove-inline-book-svg

cp -a /tmp/remove-inline-book-svg/remove-inline-book-svg/. ./

grep -R "book-world__bottle\|book-world__molecule\|book-world__portal\|book-world__aperture" -n src/components || true

rm -rf .astro dist
pnpm run check
pnpm run build
pnpm run dev -- --host 0.0.0.0

Then hard refresh the browser.
